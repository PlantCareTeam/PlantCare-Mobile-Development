package com.example.plantcare.model.histories

import com.example.plantcare.R

object HistoriesData {
    val histories = listOf(
        History(
            1,
            "Tomat",
            "Busuk Daun",
            R.drawable.dummy_diseases,
            "Phytophtheora infestans",
            "23 Mei 2023"
        ),
        History(
            2,
            "Tomat",
            "Busuk Daun",
            R.drawable.dummy_diseases,
            "Phytophtheora infestans",
            "23 Mei 2023"
        ),
        History(
            3,
            "Tomat",
            "Busuk Daun",
            R.drawable.dummy_diseases,
            "Phytophtheora infestans",
            "23 Mei 2023"
        ),
        History(
            4,
            "Tomat",
            "Busuk Daun",
            R.drawable.dummy_diseases,
            "Phytophtheora infestans",
            "23 Mei 2023"
        )

    )
}