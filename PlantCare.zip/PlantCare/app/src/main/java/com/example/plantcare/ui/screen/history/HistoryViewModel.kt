package com.example.plantcare.ui.screen.history

class HistoryViewModel {
}