package com.example.plantcare.model.predict

data class PredictResponse(
	val imageUrl: String? = null,
	val predictedLabel: String? = null
)

