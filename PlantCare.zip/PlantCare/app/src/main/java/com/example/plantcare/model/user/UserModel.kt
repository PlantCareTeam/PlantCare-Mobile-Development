package com.example.plantcare.model.user

data class UserModel(
    val token: String,
    val isLogin: Boolean
)
