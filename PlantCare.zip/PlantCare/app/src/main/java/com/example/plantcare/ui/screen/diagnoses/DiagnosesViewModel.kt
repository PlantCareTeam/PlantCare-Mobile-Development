package com.example.plantcare.ui.screen.diagnoses

class DiagnosesViewModel {
}